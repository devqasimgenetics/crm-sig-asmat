export enum SubscriptionFilters {
  All = 'All',
  Subscription = 'Subscription',
  OneTimePurchase = 'OneTimePurchase',
}
