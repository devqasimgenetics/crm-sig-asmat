import { Text } from '@radix-ui/themes';

export function Logo() {
  return <Text>React Boilerplate</Text>;
}
